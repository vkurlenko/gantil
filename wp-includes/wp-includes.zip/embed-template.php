<?php
/**
 * Back-compat placeholder for the base embed template
 *
 * @package WordPress
 * @subpackage oEmbed
 * @since 4.4.0
 * @deprecated 4.5.0 Moved to wp-includes/theme-compat/embed.php
 */

_deprecated_file( basename( __FILE__ ), '4.5.0', 'wp-includes/theme-compat/embed.php' );

include( ABSPATH . WPINC . '/theme-compat/embed.php' );
